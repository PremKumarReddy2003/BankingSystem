package Bank;

public class StudentAccount extends BankAccount {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
String  institutionName;

public StudentAccount(String name,String  institutionName, double balance ) {
	super(name, balance, 100);
	min_balance=100;
	this.institutionName=institutionName;
//	this.type="Student Account";
}


}
